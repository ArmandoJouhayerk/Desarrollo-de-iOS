import UIKit

//parte 3
var datos:Array<Int> = Array<Int> ([3,6,9,2,4,1])
for i in datos {
    if i < 5{
        print(i)
    }
}

//parte 4
func Suma(a:Int, b:Int)->String{
    let resultado = a + b;
    return "La suma de \(a) + \(b) es: \(resultado)"
}
print(Suma(a: 5, b: 6))

func Potencia(a:Int, b:Int)->String{
    let pot = a^b;
    return "La potencia de \(a) elevado a \(b) es: \(pot)"
}
print(Potencia(a: 5, b:2))


//parte 5
enum meses:Int {
    case enero = 1, febrero = 2, marzo=3, abril=4, mayo=5, junio=6, julio=7, agosto=8, septiembre=9, octubre = 10, noviembre = 11, diciembre = 12
}

var QueMesEs:meses
QueMesEs = .septiembre

switch QueMesEs {
case .enero:
    print("Es el mes numero: 1")
case .febrero:
    print("Es el mes numero: 2")
case .marzo:
    print("Es el mes numero: 3")
case .abril:
    print("Es el mes numero: 4")
case .mayo:
    print("Es el mes numero: 5")
case .junio:
    print("Es el mes numero: 6")
case .julio:
    print("Es el mes numero: 7")
case .agosto:
    print("Es el mes numero: 8")
case .septiembre:
    print("Es el mes numero: 9","= \(QueMesEs)")
case .octubre:
    print("Es el mes numero: 10")
case .noviembre:
    print("Es el mes numero: 11")
case .diciembre:
    print("Es el mes numero: 12")
default:
    print("El timepo no existe")
}
    
