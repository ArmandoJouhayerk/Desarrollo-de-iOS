//: A UIKit based Playground for presenting user interface
  
import UIKit

//Declaracion de datos
var numero = 22
let numero2: Int = 42
var decimal = 3.14
let decimal2: Float = 2.21
var String = "Actividad 3. Solucion de probleamas aplicando fundamentos Swift"
let String2: String = "Jose Armando Mendez Jouhayerk"
var cierto = true
let falso: Bool = false

//Asosiacion

var DatoInt = (N:1, H:9)
var DatoString = "Hoy es 14 de febrero"
print("El número entero N es: \(DatoInt.N) ,el dato string es: \(DatoString)")

//Arreglos

var Numeros:Array<Int> = Array<Int>()
Numeros.append(1)
Numeros.append(2)
Numeros.append(3)
Numeros.append(4)
Numeros.append(5)
Numeros.append(6)
Numeros.append(7)
Numeros.append(9)
Numeros.append(10)
Numeros.count
print("Numeros = \(Numeros)")

//Diccionarios

var diasSemana:Dictionary <Int, String> = Dictionary <Int, String>()
diasSemana = [1: "Lunes",2: "Martes",3: "Miercoles",4: "Jueves",5: "Viernes",6: "Sabado",7: "Domingo"]
print("Dias de la semana \(diasSemana)")
